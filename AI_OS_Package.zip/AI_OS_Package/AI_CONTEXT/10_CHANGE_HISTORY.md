# 10_CHANGE_HISTORY.md

**Append-only. One entry per meaningful change. Use Conventional Commits style prefixes to match git log.**

## Format
```
DATE | phase | commit-type: short description | evidence (tests run, PASS/FAIL)
```

## Log
(empty — first entry goes here once Phase 00 work begins)
