# 08_INTEGRATIONS.md

## Coding agent access (decide and record this FIRST, before Phase 00 starts)
- Chosen agent: (e.g. OpenCode + Ollama / Claude Code / Cursor)
- Access confirmed working (trivial task tested): YES / NO
- Local model in use (if applicable): (e.g. qwen2.5:7b)
- Fallback plan if local model insufficient: (e.g. free-tier API — name it)

## Affiliate networks
| Network | Status | Notes |
|---|---|---|
| Amazon Associates | (not connected yet) | Primary — PA-API needs 3 qualifying sales / 180 days to keep access |
| Flipkart Affiliate | (not connected) | Backup network — add after Phase 00 gate passes |
| Others | (not connected) | |

## Seller marketplace accounts
| Marketplace | Status | Notes |
|---|---|---|
| Amazon Seller Central | (not connected) | |
| Flipkart Seller Hub | (not connected) | |
| Meesho Supplier Panel | (not connected) | |

## Social accounts
| Platform | Status | Notes |
|---|---|---|
| YouTube | (not connected) | Daily upload quota applies (free tier) |
| Instagram | (not connected) | Needs Business/Creator account + linked FB Page; Meta App Review beyond small scale |
| Pinterest | (not connected) | Needs Business account |

## AI providers
| Provider | Status | Notes |
|---|---|---|
| Ollama (local) | (not set up) | Primary — pick model per hardware (see 02_ARCHITECTURE.md) |
| Gemini (optional) | (not connected) | Optional research/reasoning adapter, never mandatory |

## Rule
Never store actual secrets/keys in this file or any AI_CONTEXT file — record connection *status* only. Actual credentials go in `.env` (never committed) or a secrets manager.
