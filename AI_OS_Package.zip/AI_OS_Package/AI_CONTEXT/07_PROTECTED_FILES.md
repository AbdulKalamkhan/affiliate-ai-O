# 07_PROTECTED_FILES.md

**Agent must not rewrite or delete these without explicit evidence of a security/correctness problem.**

## Protected by default (once they exist)
- Any working, tested business logic
- Existing database migrations (never edit a past migration — always create a new one)
- Authentication/session configuration
- Payment/financial calculation logic
- Affiliate tracking / click-attribution logic
- Any file under `AI_CONTEXT/` — edit additively, don't wholesale overwrite without reading first
- `.env` files and anything containing secrets/credentials

## Currently protected (update as the repo grows)
(empty — nothing built yet; update this list the moment real code/migrations exist)
